<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Login page">
    <meta name="author" content="Your Name">
    <title>Halaman Login</title>
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background: linear-gradient(to bottom, red, black);
            font-family: Arial, sans-serif;
        }

        .form-signin {
            width: 100%;
            max-width: 330px;
            padding: 15px;
            margin: auto;
            background-color: white;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 5px;
        }

        .form-signin h1 {
            margin-bottom: 15px;
            font-size: 24px;
            font-weight: normal;
            text-align: center;
        }

        .form-signin input {
            margin-bottom: 10px;
            padding: 10px;
            width: calc(100% - 22px);
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .form-signin button {
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 5px;
            background-color: red;
            color: white;
            font-size: 16px;
            cursor: pointer;
        }

        .form-signin button:hover {
            background-color: darkred;
        }

        .form-signin .text-muted {
            text-align: center;
            margin-top: 15px;
            color: #6c757d;
        }

        .btn-register {
            display: block;
            margin-top: 10px;
            text-align: center;
            color: #007bff;
            cursor: pointer;
        }

        .btn-register:hover {
            text-decoration: underline;
        }

        .alert {
            background-color: #ffcc00;
            padding: 10px;
            margin-bottom: 10px;
            text-align: center;
            border-radius: 5px;
        }

        .alert-warning {
            background-color: #ffc107;
            color: #856404;
        }
    </style>
</head>

<body>
    <main class="form-signin">
        <div class="alert" id="initial-alert">
            Login terlebih dahulu!
        </div>
        <?php if (!empty(session()->getFlashdata('error'))) : ?>
            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                <?php echo session()->getFlashdata('error'); ?>
            </div>
        <?php endif; ?>
        <form method="post" action="<?= base_url(); ?>/login/process">
            <?= csrf_field(); ?>
            <h1 class="h3 mb-3 fw-normal">Login</h1>
            <input type="text" name="username" id="username" placeholder="Username" class="form-control" required autofocus>
            <input type="password" name="password" id="password" placeholder="Password" class="form-control" required>
            <button type="submit">Login</button>
            <p class="text-muted">&copy; San</p>
        </form>
        <span class="btn-register" onclick="window.location.href='<?php echo base_url('register'); ?>'">Register</span>
    </main>
    <script>
        // Show the initial alert when the page loads
        window.onload = function() {
            document.getElementById('initial-alert').style.display = 'block';
        }
    </script>
</body>

</html>
